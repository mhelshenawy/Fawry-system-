package com.fawrysystem.repository;

import com.fawrysystem.models.AdminModel;

import java.util.ArrayList;
public class AdminRepository implements CRUD{
    static ArrayList<AdminModel> adminModels = new ArrayList<AdminModel>();
    static AdminModel adminmodel =new AdminModel();
    public AdminModel getModel(){
        return adminmodel;
    }
    @Override
    public void creat(Object x) {
        adminModels.add((AdminModel) x);
    }

    @Override
    public Object find(String email, String password) {
        for (AdminModel adminModel : adminModels) {
            if (adminModel.getEmail().equals(email) && adminModel.getPassword().equals(password)) {
                adminModel.setIsActive(true);
                adminmodel=adminModel;
                return adminModel;
            }
        }
        return null;
    }

    @Override
    public boolean isActive() {
        return adminmodel.getIsActive();
    }

    @Override
    public void delete(int Email) {
        throw new RuntimeException("not used yet");
    }

    @Override
    public void update(int email) {
        throw new RuntimeException("not used yet");
    }

    @Override
    public boolean cheak(String username, String email) {
        for (int i=0; i<adminModels.size();i++){
            if (adminModels.get(i).getUsername().equals(username)||adminModels.get(i).getEmail().equals(email))
                return true;
        }
        return false;
    }
}
