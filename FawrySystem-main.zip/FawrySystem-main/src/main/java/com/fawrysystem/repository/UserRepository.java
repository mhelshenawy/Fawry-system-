package com.fawrysystem.repository;

import com.fawrysystem.models.UserModel;

import java.util.ArrayList;
import com.fawrysystem.models.UserModel;
public class UserRepository implements CRUD{
    static ArrayList<UserModel> userModels = new ArrayList<UserModel>();
    static UserModel usermodel=new UserModel();
    public UserModel getModel(){
        return usermodel;
    }
    @Override
    public void creat(Object x) {
        UserModel X= (UserModel) x;
        userModels.add(X);
    }

    @Override
    public Object find(String email, String password) {
        for (UserModel userModel : userModels) {
            if (userModel.getEmail().equals(email) && userModel.getPassword().equals(password)) {
                userModel.setIsActive(true);
                usermodel =userModel;
                return userModel;
            }
        }
        return null;
    }

    @Override
    public boolean isActive() {
        if (usermodel.getIsActive()) {
            return true;
        } else return false;
    }

    @Override
    public boolean cheak(String username , String email) {
        for (int i=0; i<userModels.size();i++){
            if (userModels.get(i).getUsername().equals(username)||userModels.get(i).getEmail().equals(email))
                return true;
        }
        return false;
    }

    @Override
    public void delete(int Email) {
        throw new RuntimeException("not used yet");
    }

    @Override
    public void update(int email) {
        throw new RuntimeException("not used yet");
    }


}
