package com.fawrysystem.repository;

import com.fawrysystem.forms.WalletForm;
import com.fawrysystem.models.PayTransactionModel;

import java.util.ArrayList;

public class AddTowalletRepository {
    static ArrayList<WalletForm> walletForms =new ArrayList<>();
    public void add(WalletForm walletForm){
        walletForms.add(walletForm);

    }

    public static ArrayList<WalletForm> getPayTransactionModels() {
        return walletForms;
    }
}
