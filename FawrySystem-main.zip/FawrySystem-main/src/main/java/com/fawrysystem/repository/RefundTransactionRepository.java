package com.fawrysystem.repository;

import com.fawrysystem.models.RefundTransactionModel;

import java.util.ArrayList;

public class RefundTransactionRepository {
    static ArrayList<RefundTransactionModel> refundTransactionModels =new ArrayList<>();
    public void add(RefundTransactionModel refundTransactionModel){
        refundTransactionModels.add(refundTransactionModel);
    }

    public ArrayList<RefundTransactionModel> getRefundTransactionModels() {
        return refundTransactionModels;
    }
}
