package com.fawrysystem.repository;

import com.fawrysystem.models.PayTransactionModel;

import java.util.ArrayList;

public class PayTransactionRepository {
    static ArrayList<PayTransactionModel> payTransactionModels =new ArrayList<>();
    public void add(PayTransactionModel payTransactionModel){
        payTransactionModels.add(payTransactionModel);

    }

    public static ArrayList<PayTransactionModel> getPayTransactionModels() {
        return payTransactionModels;
    }
}
