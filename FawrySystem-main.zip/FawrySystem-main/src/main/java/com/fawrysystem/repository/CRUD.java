package com.fawrysystem.repository;

public interface CRUD {
    void creat(Object x);
    Object find(String email, String password);
    boolean isActive();
    void delete(int Email);
    void update(int email);
    boolean cheak(String username , String email);
}
