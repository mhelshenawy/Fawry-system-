package com.fawrysystem.Service.implementation.donation;

import com.fawrysystem.Service.DonationProvider;
import com.fawrysystem.Service.implementation.signservice.UserSingn;
import com.fawrysystem.exception.ResourceNotFoundException;
import com.fawrysystem.forms.CancerHospitalForm;
import com.fawrysystem.forms.SchoolsForm;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;

public class CancerHospital implements DonationProvider {
    public static CancerHospitalForm vform =new CancerHospitalForm("",0);
    private ResourceNotFoundException resourceNotFoundException;
    private UserSingn userSingn=new UserSingn();
    public CancerHospital(String name , double amount){
        vform=new CancerHospitalForm(name,amount);
    }
    public CancerHospital(){

    }
    @Override
    public double getAmount() {
        return vform.getAmount();
    }

    @Override
    public ResponseEntity<Object> DonationService(String name, double amount) {
        if (userSingn.isActive()){
            return new ResponseEntity<>(vform, HttpStatus.OK);
        }else {
            resourceNotFoundException =new ResourceNotFoundException("CancerHospital","User","not active");
            return new ResponseEntity<>(resourceNotFoundException,HttpStatus.LOCKED);
        }
    }
}
