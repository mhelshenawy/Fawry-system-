package com.fawrysystem.Service.implementation.signservice;

import com.fawrysystem.Service.SignService;
import com.fawrysystem.models.AdminModel;
import com.fawrysystem.models.UserModel;
import com.fawrysystem.repository.AdminRepository;

public class AdminSingn implements SignService {
    private AdminRepository adminRepository =new AdminRepository();
    @Override
    public Object sinin(Object x) {
        AdminModel adminModel = (AdminModel) x;
        if (adminRepository.find(adminModel.getEmail(),adminModel.getPassword())!=null)
            return adminRepository.find(adminModel.getEmail(),adminModel.getPassword());
        else return  null;
    }

    @Override
    public Object sinup(Object x) {
        AdminModel adminModel = (AdminModel) x;
        if (adminRepository.cheak(adminModel.getUsername(),adminModel.getEmail())){
            return  null;
        }else
            adminRepository.creat(x);
        return x;
    }

    @Override
    public boolean isActive() {
        return this.adminRepository.isActive();
    }
}
