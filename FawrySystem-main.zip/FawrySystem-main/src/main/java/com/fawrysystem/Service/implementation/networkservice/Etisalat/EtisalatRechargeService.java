package com.fawrysystem.Service.implementation.networkservice.Etisalat;

import com.fawrysystem.Service.RechargeService;
import com.fawrysystem.Service.implementation.signservice.UserSingn;
import com.fawrysystem.exception.ResourceNotFoundException;
import com.fawrysystem.exception.UserNotFound;
import com.fawrysystem.forms.EtisalatInternetForm;
import com.fawrysystem.forms.EtisalatRechargeForm;
import com.fawrysystem.forms.VodafoneRechargeForm;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;

@Data

public class EtisalatRechargeService implements RechargeService {
    private int number;

    private double tax = 8.0;
    private double NewCredit=0;
    public static EtisalatRechargeForm vform;
    private UserNotFound userNotFound;
    private UserSingn userSingn=new UserSingn();
    private EtisalatInternetForm etisalatInternetForm ;
    public EtisalatRechargeService(int number , double NewCredit){
        this.number=number;
        this.NewCredit=NewCredit;

    }
    public EtisalatRechargeService(){
        etisalatInternetForm =new EtisalatInternetForm(8.0,number,0);
    }
    @Override
    public double cluceInternetAmount() {
        double sum  = NewCredit+(NewCredit*.08);
        vform.setCost(sum);
        return sum;
    }

    @Override
    public double getTax() {
        return vform.getTax();
    }

    @Override
    public double getcredit() {
        return vform.getNewCredit();
    }

    @Override
    public ResponseEntity<Object> rechargeService(int number , double newCredit ){
        vform=new EtisalatRechargeForm(number,8.0,newCredit,0);
        if (userSingn.isActive()){
            vform.setNewCredit(newCredit);
            vform.setNumber(number);
            vform.setUserName(userSingn.getUserRepository().getModel().getUsername());
            cluceInternetAmount();
            return new ResponseEntity<>(vform, HttpStatus.OK);
        }else {
            userNotFound =new UserNotFound("Recharge","user not sgin" , Double.toString(vform.getCost()));
            throw userNotFound;
        }
    }
}
