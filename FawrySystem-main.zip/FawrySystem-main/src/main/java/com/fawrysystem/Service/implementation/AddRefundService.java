package com.fawrysystem.Service.implementation;

import com.fawrysystem.models.RefundTransactionModel;
import com.fawrysystem.repository.RefundTransactionRepository;
import com.fawrysystem.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class AddRefundService {
    RefundTransactionRepository refundTransactionRepository=new RefundTransactionRepository();
    UserRepository userRepository =new UserRepository();
    public ResponseEntity<Object> acceptRefund(RefundTransactionModel refundTransactionModel){
        for (int i=0; i<refundTransactionRepository.getRefundTransactionModels().size();i++){
            if (userRepository.isActive()&&refundTransactionModel.getUserName().equals(refundTransactionRepository.getRefundTransactionModels().get(i).getUserName())
                    && refundTransactionModel.getTransactionName().equals(refundTransactionRepository.getRefundTransactionModels().get(i).getTransactionName())){
                return new ResponseEntity<>(refundTransactionRepository.getRefundTransactionModels().get(i), HttpStatus.OK);
            }
        }
        return null;
    }
}
