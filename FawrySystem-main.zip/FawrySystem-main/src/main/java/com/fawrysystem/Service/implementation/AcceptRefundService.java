package com.fawrysystem.Service.implementation;

import com.fawrysystem.exception.AdminNotFound;
import com.fawrysystem.models.RefundTransactionModel;
import com.fawrysystem.repository.AdminRepository;
import com.fawrysystem.repository.RefundTransactionRepository;
import com.fawrysystem.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class AcceptRefundService {
    RefundTransactionRepository refundTransactionRepository=new RefundTransactionRepository();
    UserRepository userRepository =new UserRepository();
    AdminRepository adminRepository =new AdminRepository();
    AdminNotFound adminNotFound;

    public ResponseEntity<Object> acceptRefund(RefundTransactionModel refundTransactionModel){
        for (int i=0; i<refundTransactionRepository.getRefundTransactionModels().size();i++){
            if (adminRepository.isActive()&&refundTransactionModel.getUserName().equals(refundTransactionRepository.getRefundTransactionModels().get(i).getUserName())
                    && refundTransactionModel.getTransactionName().equals(refundTransactionRepository.getRefundTransactionModels().get(i).getTransactionName())){
                userRepository.getModel().setWallet(userRepository.getModel().getWallet()+refundTransactionModel.getPrice());
                refundTransactionRepository.getRefundTransactionModels().remove(i);
                return new ResponseEntity<>(refundTransactionModel, HttpStatus.OK);
            }
        }
        adminNotFound =new AdminNotFound("acceptRefund","admin not sign" , refundTransactionModel.getTransactionName());
        throw adminNotFound;
    }
}
