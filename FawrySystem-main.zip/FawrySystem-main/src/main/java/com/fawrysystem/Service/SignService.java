package com.fawrysystem.Service;

public interface SignService {
    Object sinin(Object x);
    Object sinup(Object x);
    boolean isActive();
}
