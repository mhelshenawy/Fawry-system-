package com.fawrysystem.Service.implementation.networkservice.Vodafone;

import com.fawrysystem.Service.RechargeService;
import com.fawrysystem.Service.implementation.signservice.UserSingn;
import com.fawrysystem.exception.ResourceNotFoundException;
import com.fawrysystem.exception.UserNotFound;
import com.fawrysystem.forms.EtisalatRechargeForm;
import com.fawrysystem.forms.VodafoneInternetForm;
import com.fawrysystem.forms.VodafoneRechargeForm;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;

public class VodafoneRechargeService implements RechargeService {
    public static VodafoneRechargeForm vform ;
    private UserNotFound userNotFound;
    private static double cost;

    private UserSingn userSingn=new UserSingn();
    public VodafoneRechargeService(int number, double NewCredit){
       vform=new VodafoneRechargeForm(number,8.0,NewCredit,NewCredit);
    }
    public VodafoneRechargeService(){

    }
    @Override
    public double cluceInternetAmount() {
        double sum  = vform.getNewCredit()+(vform.getNewCredit()*.08);
        vform.setCost(sum);
        cost = sum;
        return sum;
    }

    @Override
    public double getTax() {
        return vform.getTax();
    }

    @Override
    public double getcredit() {
        return cost;
    }
    public ResponseEntity<Object> rechargeService(int number , double newCredit ){
        vform=new VodafoneRechargeForm(number,8.0,newCredit,0);
        if (userSingn.isActive()){
            vform.setNewCredit(newCredit);
            vform.setNumber(number);
            vform.setUserName(userSingn.getUserRepository().getModel().getUsername());
            cluceInternetAmount();
            return new ResponseEntity<>(vform, HttpStatus.OK);
        }else {
            userNotFound =new UserNotFound("Recharge","user not sgin" , Double.toString(vform.getCost()));
            throw userNotFound;
        }
    }

}
