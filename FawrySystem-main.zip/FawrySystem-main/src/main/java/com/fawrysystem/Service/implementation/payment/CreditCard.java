package com.fawrysystem.Service.implementation.payment;

import com.fawrysystem.Service.Payment;
import com.fawrysystem.repository.UserRepository;
import org.springframework.http.ResponseEntity;

public class CreditCard implements Payment {
    private UserRepository user;
    @Override
    public boolean pay(double price) {
        if (user.getModel().getWallet()>=price){
            user.getModel().setWallet(user.getModel().getWallet()-price);
            return true;
        }else return false;
    }

    @Override
    public ResponseEntity<Object> internetPaymentVodafone() {
        return null;
    }

    @Override
    public ResponseEntity<Object> internetPaymentEtisalat() {
        return null;
    }

    @Override
    public ResponseEntity<Object> rechargeEtisalat() {
        return null;
    }

    @Override
    public ResponseEntity<Object> rechargeVodafone() {
        return null;
    }

    @Override
    public ResponseEntity<Object> schoolDonation() {
        return null;
    }

    @Override
    public ResponseEntity<Object> cancerHospitalDonation() {
        return null;
    }


}
