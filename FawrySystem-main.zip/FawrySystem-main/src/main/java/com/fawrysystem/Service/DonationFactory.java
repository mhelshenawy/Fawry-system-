package com.fawrysystem.Service;

import org.springframework.http.ResponseEntity;

public interface DonationFactory {
    DonationProvider createDonation(String name , double amount);

}
