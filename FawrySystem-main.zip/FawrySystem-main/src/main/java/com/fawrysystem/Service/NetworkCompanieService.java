package com.fawrysystem.Service;

public interface NetworkCompanieService {
    InternetPaymentService createInternetPaymentService(int phoneNumber);
    RechargeService createRechargeService(int number , double NewCredit);
}
