package com.fawrysystem.Service.implementation;

import com.fawrysystem.Service.AddToWallet;
import com.fawrysystem.exception.UserNotFound;
import com.fawrysystem.forms.WalletForm;
import com.fawrysystem.repository.AddTowalletRepository;
import com.fawrysystem.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class AddtoWalletService implements AddToWallet {
    private UserRepository user=new UserRepository();
    private UserNotFound userNotFound;
    private AddTowalletRepository addTowalletRepository =new AddTowalletRepository();

    @Override
    public ResponseEntity<Object> add(double amount) {
        if (user.isActive()){
            WalletForm walletForm =new WalletForm();
            user.getModel().setWallet(amount+user.getModel().getWallet());
            walletForm.setPrice(amount);
            walletForm.setUserName(user.getModel().getUsername());
            addTowalletRepository.add(walletForm);
            return new ResponseEntity<>(user.getModel(),HttpStatus.OK);
        }else {
            userNotFound=new UserNotFound("userNotFound","addTowallet", Double.toString(amount));
            throw userNotFound;
        }
    }
}
