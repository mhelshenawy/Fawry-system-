package com.fawrysystem.Service.implementation.donation;

import com.fawrysystem.Service.DonationFactory;
import com.fawrysystem.Service.DonationProvider;

public class CreateCancerHospital implements DonationFactory {
    DonationProvider donationProvider;
    @Override
    public DonationProvider createDonation( String name , double amount){
        donationProvider =new CancerHospitalService(name,amount);
        return donationProvider;
    }
}
