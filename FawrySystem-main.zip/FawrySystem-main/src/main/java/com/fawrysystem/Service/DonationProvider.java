package com.fawrysystem.Service;

import org.springframework.http.ResponseEntity;

public interface DonationProvider {
    double getAmount();
    ResponseEntity<Object> DonationService(String name, double amount);

}
