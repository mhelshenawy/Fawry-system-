package com.fawrysystem.Service;

import com.fawrysystem.models.RefundTransactionModel;
import org.springframework.http.ResponseEntity;

public interface Refundtransaction {
    ResponseEntity<Object> listUserTransaction();
    ResponseEntity<Object> addRefundTransaction(RefundTransactionModel refundTransactionModel);
}
