package com.fawrysystem.Service.implementation.networkservice.Vodafone;

import com.fawrysystem.Service.InternetPaymentService;
import com.fawrysystem.Service.NetworkCompanieService;
import com.fawrysystem.Service.RechargeService;
import org.springframework.stereotype.Service;

@Service
public class VodafoneFactoryService implements NetworkCompanieService {
    static private InternetPaymentService internetPaymentService;

    static private RechargeService rechargeService;
    @Override
    public InternetPaymentService createInternetPaymentService(int phoneNumber) {
        internetPaymentService=new VodafoneInternetPaymentService(phoneNumber);
        return internetPaymentService;
    }

    @Override
    public RechargeService createRechargeService(int number, double NewCredit) {
        rechargeService=new VodafoneRechargeService(number,NewCredit);
        return rechargeService;
    }

    public  RechargeService getRechargeService() {
        return rechargeService;
    }
    public  InternetPaymentService getInternetPaymentService(){
        return internetPaymentService;
    }
}
