package com.fawrysystem.Service.implementation.networkservice.Etisalat;

import com.fawrysystem.Service.InternetPaymentService;
import com.fawrysystem.Service.implementation.signservice.UserSingn;
import com.fawrysystem.exception.ResourceNotFoundException;
import com.fawrysystem.exception.UserNotFound;
import com.fawrysystem.forms.EtisalatInternetForm;
import com.fawrysystem.forms.VodafoneInternetForm;
import lombok.Data;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;

@Data
public class EtisalatInternetPaymentService implements InternetPaymentService {
    private int phoneNumber;

    public static EtisalatInternetForm vform;
    private UserNotFound userNotFound;
    private UserSingn userSingn=new UserSingn();
    public EtisalatInternetPaymentService(int phoneNumber){
        vform=new EtisalatInternetForm(8.0,phoneNumber,0);
        this.phoneNumber=phoneNumber;
    }
    public EtisalatInternetPaymentService(){

    }
    @Override
    public double cluceInternetAmount() {
        double sum=0;
        while(vform.getPhoneNumber()!=0) {
            sum += vform.getPhoneNumber()%10;
            vform.setPhoneNumber(vform.getPhoneNumber()/10);
        }
        sum = sum +(sum*0.08);
        vform.setCost(sum);
        vform.setPhoneNumber(phoneNumber);
        return sum;
    }
    @Override
    public double getTax() {
        return vform.getTax();
    }
    public double getCost(){
        return vform.getCost();
    }

    @Override
    public ResponseEntity<Object> internetPaymentService(int number) {
        if (userSingn.isActive()){
            vform.setPhoneNumber(number);
            vform.setUserName(userSingn.getUserRepository().getModel().getUsername());
            cluceInternetAmount();
            return new ResponseEntity<>(vform, HttpStatus.OK);
        }else {
            userNotFound =new UserNotFound("inetnetPayment","user not sgin" , Double.toString(vform.getCost()));
            throw userNotFound;
        }
    }

}
