package com.fawrysystem.Service.implementation.networkservice.Etisalat;

import com.fawrysystem.Service.InternetPaymentService;
import com.fawrysystem.Service.NetworkCompanieService;
import com.fawrysystem.Service.RechargeService;

public class EtisalatFactoryService implements NetworkCompanieService {
    static private InternetPaymentService internetPaymentService;
    static private RechargeService rechargeService;
    @Override
    public InternetPaymentService createInternetPaymentService(int phoneNumber) {
        internetPaymentService= new EtisalatInternetPaymentService(phoneNumber);
        return internetPaymentService;
    }

    @Override
    public RechargeService createRechargeService(int number , double NewCredit) {
        rechargeService=new EtisalatRechargeService( number,NewCredit);
        return rechargeService;
    }

    public  InternetPaymentService getInternetPaymentService() {
        return internetPaymentService;
    }

    public  RechargeService getRechargeService() {
        return rechargeService;
    }
}
