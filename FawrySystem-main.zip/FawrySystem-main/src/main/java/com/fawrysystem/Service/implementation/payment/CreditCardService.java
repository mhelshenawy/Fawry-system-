package com.fawrysystem.Service.implementation.payment;

import com.fawrysystem.Service.Payment;
import com.fawrysystem.Service.implementation.donation.CancerHospitalService;
import com.fawrysystem.Service.implementation.donation.Schools;
import com.fawrysystem.Service.implementation.networkservice.Etisalat.EtisalatInternetPaymentService;
import com.fawrysystem.Service.implementation.networkservice.Etisalat.EtisalatRechargeService;
import com.fawrysystem.Service.implementation.networkservice.Vodafone.VodafoneInternetPaymentService;
import com.fawrysystem.Service.implementation.networkservice.Vodafone.VodafoneRechargeService;
import com.fawrysystem.exception.CantPayExeption;
import com.fawrysystem.models.PayTransactionModel;
import com.fawrysystem.repository.PayTransactionRepository;
import com.fawrysystem.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class CreditCardService implements Payment {
    private PayTransactionModel payTransactionModel=new PayTransactionModel();
    private PayTransactionRepository payTransactionRepository =new PayTransactionRepository();
    private UserRepository user=new UserRepository();
    private VodafoneInternetPaymentService vodafoneInternetPaymentService =new VodafoneInternetPaymentService();
    private VodafoneRechargeService vodafoneRechargeService =new VodafoneRechargeService();
    private EtisalatInternetPaymentService etisalatInternetPaymentService= new EtisalatInternetPaymentService();
    private EtisalatRechargeService etisalatRechargeService =new EtisalatRechargeService();
    private Schools schools;
    private CancerHospitalService cancerHospital ;
    private CantPayExeption cantPayExeption;
    @Override
    public boolean pay(double price) {
        if (user.getModel().getWallet()>=price){
            user.getModel().setWallet(user.getModel().getWallet()-price);
            return true;
        }else return false;
    }

    @Override
    public ResponseEntity<Object> internetPaymentVodafone(){
        if (user.isActive()&&pay(vodafoneInternetPaymentService.getCost())){
            System.out.println(vodafoneInternetPaymentService.getCost());
            vodafoneInternetPaymentService.vform.setUserName(user.getModel().getUsername());
            payTransactionModel.setUserName(user.getModel().getUsername());
            payTransactionModel.setTransactionName("internetPaymentVodafone");
            payTransactionModel.setPrice(vodafoneInternetPaymentService.getCost());
            payTransactionRepository.add(payTransactionModel);
            vodafoneInternetPaymentService.vform.getVodafoneInternetForms().add(vodafoneInternetPaymentService.vform);
            return new ResponseEntity<>(vodafoneInternetPaymentService, HttpStatus.OK);
        }
        else {
            cantPayExeption=new CantPayExeption("PayInternetService","Vodafone","Not active");
            return new ResponseEntity<>(vodafoneInternetPaymentService, HttpStatus.NOT_ACCEPTABLE);
        }
    }
    @Override
    public ResponseEntity<Object> rechargeVodafone() {
        if (user.isActive()&&pay(vodafoneRechargeService.getcredit())){
            vodafoneRechargeService.vform.setUserName(user.getModel().getUsername());
            vodafoneRechargeService.vform.getVodafoneRechargeForms().add(vodafoneRechargeService.vform);
            payTransactionModel.setUserName(user.getModel().getUsername());
            payTransactionModel.setTransactionName("internetPaymentVodafone");
            payTransactionModel.setPrice(vodafoneRechargeService.getcredit());
            payTransactionRepository.add(payTransactionModel);
            return new ResponseEntity<>(vodafoneRechargeService, HttpStatus.OK);
        }
        else{
            cantPayExeption=new CantPayExeption("RechargeService","Vodafone","Not active");
            return new ResponseEntity<>(cantPayExeption, HttpStatus.NOT_ACCEPTABLE);
        }
    }
    @Override
    public ResponseEntity<Object> internetPaymentEtisalat(){
        if (user.isActive()&&pay(etisalatInternetPaymentService.getCost())){
            etisalatInternetPaymentService.vform.getEtisalatInternetForms().add(etisalatInternetPaymentService.vform);
            payTransactionModel.setUserName(user.getModel().getUsername());
            payTransactionModel.setTransactionName("internetPaymentEtisalat");
            payTransactionModel.setPrice(etisalatInternetPaymentService.getCost());
            payTransactionRepository.add(payTransactionModel);
            return new ResponseEntity<>(etisalatInternetPaymentService, HttpStatus.OK);
        }
        else{
            cantPayExeption=new CantPayExeption("PayInternetService","Etisalat","Not active");
            return new ResponseEntity<>(cantPayExeption, HttpStatus.NOT_ACCEPTABLE);
        }

    }
    @Override
    public ResponseEntity<Object> rechargeEtisalat(){
        if (user.isActive()&&pay(etisalatRechargeService.getcredit())){
            EtisalatRechargeService.vform.getEtisalatRechargeForms().add(etisalatRechargeService.vform);
            payTransactionModel.setUserName(user.getModel().getUsername());
            payTransactionModel.setTransactionName("rechargeEtisalat");
            payTransactionModel.setPrice(etisalatRechargeService.getcredit());
            payTransactionRepository.add(payTransactionModel);
            return new ResponseEntity<>(etisalatRechargeService, HttpStatus.OK);
        }
        else{
            cantPayExeption=new CantPayExeption("RechargeService","Etisalat","Not active");
            return new ResponseEntity<>(cantPayExeption, HttpStatus.NOT_ACCEPTABLE);
        }
    }
    @Override
    public ResponseEntity<Object> schoolDonation(){
        schools =new Schools();
        if (user.isActive()&&pay(schools.getAmount())){
            schools.vform.getSchoolsForms().add(schools.vform);
            payTransactionModel.setUserName(user.getModel().getUsername());
            payTransactionModel.setTransactionName("schoolDonation");
            payTransactionModel.setPrice(schools.getAmount());
            payTransactionRepository.add(payTransactionModel);
            return new ResponseEntity<>(schools , HttpStatus.OK);
        }else {
            cantPayExeption =new CantPayExeption("schoolDonation" , "Donation" , "Not active");
            return new ResponseEntity<>(cantPayExeption,HttpStatus.NOT_ACCEPTABLE);
        }
    }
    @Override
    public ResponseEntity<Object> cancerHospitalDonation(){
        cancerHospital = new CancerHospitalService();
        if (user.isActive()&&pay(cancerHospital.getAmount())){
            cancerHospital.vform.getCancerHospitals().add(cancerHospital.vform);
            payTransactionModel.setUserName(user.getModel().getUsername());
            payTransactionModel.setTransactionName("cancerHospitalDonation");
            payTransactionModel.setPrice(cancerHospital.getAmount());
            payTransactionRepository.add(payTransactionModel);
            return new ResponseEntity<>(cancerHospital , HttpStatus.OK);
        }else {
            cantPayExeption =new CantPayExeption("cancerHospital" , "Donation" , "Not active");
            return new ResponseEntity<>(cantPayExeption,HttpStatus.NOT_ACCEPTABLE);
        }
    }


}
