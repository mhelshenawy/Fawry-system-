package com.fawrysystem.Service;

import org.springframework.http.ResponseEntity;

public interface RechargeService {
    double cluceInternetAmount();
    double getTax();
    double getcredit();
    ResponseEntity<Object> rechargeService(int number , double newCredit );

}
