package com.fawrysystem.Service.implementation.networkservice.Vodafone;

import com.fawrysystem.Service.InternetPaymentService;
import com.fawrysystem.Service.implementation.signservice.UserSingn;
import com.fawrysystem.exception.ResourceNotFoundException;
import com.fawrysystem.exception.UserNotFound;
import com.fawrysystem.forms.VodafoneInternetForm;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;

public class VodafoneInternetPaymentService implements InternetPaymentService {
    public static VodafoneInternetForm vform;
    private static double cost;
    private UserNotFound userNotFound;
    private UserSingn userSingn=new UserSingn();

    public VodafoneInternetPaymentService(){
        vform=new VodafoneInternetForm(0,8.0,0);
    }
    public VodafoneInternetPaymentService(int phoneNumber){
        vform=new VodafoneInternetForm(phoneNumber,8.0,0);
    }
    @Override
    public double cluceInternetAmount() {
        double sum =0;
        vform.setCost(0);
        while(vform.getPhoneNumber()!=0) {
            sum+=10;
            vform.setPhoneNumber(vform.getPhoneNumber()/10);
        }
        sum = sum +(sum*0.085);
        vform.setCost(sum);
        cost =sum;
        return sum;
    }

    @Override
    public double getTax() {

        return vform.getTax();

    }
    public double getCost(){
        return cost;
    }
    public int getPhoneNumber(){
        return vform.getPhoneNumber();
    }
    public ResponseEntity<Object> internetPaymentService(int number ){
        vform =new VodafoneInternetForm(number,8.0,cluceInternetAmount());
        if (userSingn.isActive()){
            vform.setUserName(userSingn.getUserRepository().getModel().getUsername());
            vform.setPhoneNumber(number);
            cluceInternetAmount();
            return new ResponseEntity<>(vform, HttpStatus.OK);
        }else {
            userNotFound =new UserNotFound("inetnetPayment","user not sgin" , Double.toString(vform.getCost()));
            throw userNotFound;
        }

    }


}
