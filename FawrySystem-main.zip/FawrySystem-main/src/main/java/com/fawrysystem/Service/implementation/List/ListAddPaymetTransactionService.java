package com.fawrysystem.Service.implementation.List;

import com.fawrysystem.Service.IListTransaction;
import com.fawrysystem.exception.AdminNotFound;
import com.fawrysystem.repository.AdminRepository;
import com.fawrysystem.repository.PayTransactionRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class ListAddPaymetTransactionService implements IListTransaction {
    PayTransactionRepository payTransactionRepository =new PayTransactionRepository();
    AdminRepository adminRepository =new AdminRepository();
    AdminNotFound adminNotFound =new AdminNotFound("admin not found" ,"List Pay Transaction","list of pay ");

    @Override
    public ResponseEntity<Object> ListTransaction() {
        if (adminRepository.isActive())
            return new ResponseEntity<>(payTransactionRepository.getPayTransactionModels(), HttpStatus.OK);
        else throw adminNotFound;
    }
}
