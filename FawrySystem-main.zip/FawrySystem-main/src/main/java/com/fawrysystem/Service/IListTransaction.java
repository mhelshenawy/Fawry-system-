package com.fawrysystem.Service;

import org.springframework.http.ResponseEntity;

public interface IListTransaction {
    ResponseEntity<Object> ListTransaction();

}
