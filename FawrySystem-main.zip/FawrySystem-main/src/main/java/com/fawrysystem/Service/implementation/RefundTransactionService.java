package com.fawrysystem.Service.implementation;

import com.fawrysystem.Service.Refundtransaction;
import com.fawrysystem.exception.UserNotFound;
import com.fawrysystem.models.PayTransactionModel;
import com.fawrysystem.models.RefundTransactionModel;
import com.fawrysystem.repository.AdminRepository;
import com.fawrysystem.repository.PayTransactionRepository;
import com.fawrysystem.repository.RefundTransactionRepository;
import com.fawrysystem.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;

public class RefundTransactionService implements Refundtransaction {
    private PayTransactionRepository payTransactionRepository = new PayTransactionRepository();
    private RefundTransactionRepository refundTransactionRepository =new RefundTransactionRepository();
    private UserRepository user =new UserRepository();
    private AdminRepository adminRepository =new AdminRepository();
    private UserNotFound userNotFound;
    @Override
    public ResponseEntity<Object> listUserTransaction() {
        ArrayList<PayTransactionModel> array =new ArrayList<>();
        if (user.isActive()){
            for (int i =0; i<payTransactionRepository.getPayTransactionModels().size();i++){
                if (payTransactionRepository.getPayTransactionModels().get(i).getUserName().equals(user.getModel().getUsername())){
                    System.out.println(payTransactionRepository.getPayTransactionModels().get(i));
                    array.add(payTransactionRepository.getPayTransactionModels().get(i));
                }
            }
            return new ResponseEntity<>(array, HttpStatus.OK);
        }
        return null;

    }

    @Override
    public ResponseEntity<Object> addRefundTransaction(RefundTransactionModel refundTransactionModel) {
        if (user.isActive()){
            refundTransactionRepository.add(refundTransactionModel);
            return new ResponseEntity<>(refundTransactionModel ,HttpStatus.OK) ;
        }
        userNotFound=new UserNotFound("userNotFound","addRefundTransaction", refundTransactionModel.getTransactionName());
        throw userNotFound;

    }

}
