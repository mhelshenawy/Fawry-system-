package com.fawrysystem.Service.implementation.donation;

import com.fawrysystem.Service.DonationProvider;
import com.fawrysystem.Service.implementation.signservice.UserSingn;
import com.fawrysystem.exception.ResourceNotFoundException;
import com.fawrysystem.exception.UserNotFound;
import com.fawrysystem.forms.CancerHospitalForm;
import com.fawrysystem.forms.SchoolsForm;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;

public class Schools implements DonationProvider {
    public static SchoolsForm vform=new SchoolsForm(" ",0);
    private UserNotFound userNotFound;
    private UserSingn userSingn=new UserSingn();
    public Schools(String name , double amount){
        vform=new SchoolsForm(name,amount);
    }
    public Schools(){

    }
    @Override
    public double getAmount() {
        return vform.getAmount();
    }

    @Override
    public ResponseEntity<Object> DonationService(String name, double amount) {
        vform=new SchoolsForm(name,amount);
        vform.setUserName(userSingn.getUserRepository().getModel().getUsername());
        if (userSingn.isActive()){
            return new ResponseEntity<>(vform, HttpStatus.OK);
        }else {
            userNotFound =new UserNotFound("Schools","user not sgin" , Double.toString(amount));
            throw userNotFound;
        }
    }
}
