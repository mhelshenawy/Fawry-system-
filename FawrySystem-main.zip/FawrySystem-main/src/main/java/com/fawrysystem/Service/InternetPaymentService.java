package com.fawrysystem.Service;

import com.fawrysystem.forms.EtisalatInternetForm;
import org.springframework.http.ResponseEntity;

public interface InternetPaymentService {
    double cluceInternetAmount();

    double getTax();

    ResponseEntity<Object> internetPaymentService(int number);
}
