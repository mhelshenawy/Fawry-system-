package com.fawrysystem.Service.implementation.List;

import com.fawrysystem.Service.IListTransaction;
import com.fawrysystem.exception.AdminNotFound;
import com.fawrysystem.repository.AdminRepository;
import com.fawrysystem.repository.RefundTransactionRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class ListRefundTransactionService implements IListTransaction {
    RefundTransactionRepository refundTransactionRepository =new RefundTransactionRepository();
    AdminRepository adminRepository =new AdminRepository();
    AdminNotFound adminNotFound =new AdminNotFound("admin not found" ,"ListRefundTransaction","list of refund ");

    @Override
    public ResponseEntity<Object> ListTransaction() {
        if (adminRepository.isActive()){
            return new ResponseEntity<>(refundTransactionRepository.getRefundTransactionModels(), HttpStatus.OK);
        }else throw adminNotFound;
    }
}
