package com.fawrysystem.Service.implementation.List;

import com.fawrysystem.Service.IListTransaction;
import com.fawrysystem.exception.AdminNotFound;
import com.fawrysystem.repository.AddTowalletRepository;
import com.fawrysystem.repository.AdminRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;

public class ListAddToWallet implements IListTransaction {
    AddTowalletRepository addTowalletRepository =new AddTowalletRepository();
    AdminRepository adminRepository =new AdminRepository();
    AdminNotFound adminNotFound =new AdminNotFound("admin not found" ,"ListAddToWalletTransaction","list of addToWallet ");
    @Override
    public ResponseEntity<Object> ListTransaction() {
        if (adminRepository.isActive()){
            return new ResponseEntity<>(addTowalletRepository.getPayTransactionModels(), HttpStatus.OK);
        }else throw adminNotFound;
    }
}
