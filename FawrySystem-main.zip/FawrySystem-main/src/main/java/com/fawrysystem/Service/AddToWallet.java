package com.fawrysystem.Service;

import org.springframework.http.ResponseEntity;

public interface AddToWallet {
    ResponseEntity<Object> add(double amount);
}
