package com.fawrysystem.Service.implementation.donation;

import com.fawrysystem.Service.DonationProvider;
import com.fawrysystem.Service.implementation.signservice.UserSingn;
import com.fawrysystem.exception.UserNotFound;
import com.fawrysystem.forms.CancerHospitalForm;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class CancerHospitalService implements DonationProvider {
    public static CancerHospitalForm vform =new CancerHospitalForm("",0);
    private UserNotFound userNotFound;
    private UserSingn userSingn=new UserSingn();
    public CancerHospitalService(String name , double amount){
        vform=new CancerHospitalForm(name,amount);
    }
    public CancerHospitalService(){

    }
    @Override
    public double getAmount() {
        return vform.getAmount();
    }

    @Override
    public ResponseEntity<Object> DonationService(String name, double amount) {
        vform =new CancerHospitalForm(name,amount);
        vform.setUserName(userSingn.getUserRepository().getModel().getUsername());
        if (userSingn.isActive()){
            return new ResponseEntity<>(vform, HttpStatus.OK);
        }else {
            userNotFound =new UserNotFound("DonationService","user not sgin" , Double.toString(amount));
            throw userNotFound;
        }
    }
}
