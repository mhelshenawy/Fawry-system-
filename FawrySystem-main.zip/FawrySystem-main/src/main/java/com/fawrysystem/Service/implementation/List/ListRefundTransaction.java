package com.fawrysystem.Service.implementation.List;

import com.fawrysystem.Service.IListTransaction;
import com.fawrysystem.models.RefundTransactionModel;
import com.fawrysystem.repository.RefundTransactionRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class ListRefundTransaction implements IListTransaction {
    RefundTransactionRepository refundTransactionRepository =new RefundTransactionRepository();
    @Override
    public ResponseEntity<Object> ListTransaction() {

        return new ResponseEntity<>(refundTransactionRepository.getRefundTransactionModels(), HttpStatus.OK);
    }
}
