package com.fawrysystem.Service.implementation.donation;

import com.fawrysystem.Service.DonationFactory;
import com.fawrysystem.Service.DonationProvider;

public class CreateSchoolsDonation implements DonationFactory {
    DonationProvider donationProvider;
    @Override
    public DonationProvider createDonation(String name , double amount) {
        donationProvider =new Schools(name ,amount);
        return donationProvider;
    }
}
