package com.fawrysystem.Service;

import org.springframework.http.ResponseEntity;

public interface Payment {
    boolean pay(double price);
    ResponseEntity<Object> internetPaymentVodafone();
    ResponseEntity<Object> internetPaymentEtisalat();
    ResponseEntity<Object> rechargeEtisalat();
    ResponseEntity<Object> rechargeVodafone();
    ResponseEntity<Object> schoolDonation();
    ResponseEntity<Object> cancerHospitalDonation();


}
