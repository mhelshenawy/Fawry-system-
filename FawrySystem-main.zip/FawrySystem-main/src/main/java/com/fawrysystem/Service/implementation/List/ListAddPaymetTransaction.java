package com.fawrysystem.Service.implementation.List;

import com.fawrysystem.Service.IListTransaction;
import com.fawrysystem.repository.PayTransactionRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
public class ListAddPaymetTransaction implements IListTransaction {
    PayTransactionRepository payTransactionRepository =new PayTransactionRepository();

    @Override
    public ResponseEntity<Object> ListTransaction() {

        return new ResponseEntity<>(payTransactionRepository.getPayTransactionModels(), HttpStatus.OK);

    }
}
