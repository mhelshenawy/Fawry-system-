package com.fawrysystem.Service.implementation.signservice;

import com.fawrysystem.Service.SignService;
import com.fawrysystem.models.UserModel;
import com.fawrysystem.repository.UserRepository;

public class UserSingn implements SignService {
    private static UserRepository userRepository= new UserRepository();

    @Override
    public Object sinin(Object x) {
        UserModel userModel = (UserModel) x;
        if (userRepository.find(userModel.getEmail(),userModel.getPassword())!=null)
            return userRepository.find(userModel.getEmail(),userModel.getPassword());
        else return  null;
    }

    @Override
    public Object sinup(Object x) {
        UserModel userModel = (UserModel) x;
        if (userRepository.cheak(userModel.getUsername(),userModel.getEmail())){
            return  null;
        }else
            userRepository.creat(x);
        return x;
    }
    @Override
    public boolean isActive() {
        return userRepository.isActive();
    }

    public static UserRepository getUserRepository() {
        return userRepository;
    }
}
