package com.fawrysystem.forms;
import java.util.ArrayList;

public class CancerHospitalForm {
    private static ArrayList<CancerHospitalForm> cancerHospitals=new ArrayList<>();
    private String name;
    private double amount;
    private String userName="null";

    public CancerHospitalForm(String name, double amount) {
        this.name = name;
        this.amount = amount;
    }

    public String getName() {
        return name;
    }

    public double getAmount() {
        return amount;
    }

    public String getUserName() {
        return userName;
    }

    public static void setCancerHospitals(ArrayList<CancerHospitalForm> cancerHospitals) {
        CancerHospitalForm.cancerHospitals = cancerHospitals;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public static ArrayList<CancerHospitalForm> getCancerHospitals() {
        return cancerHospitals;
    }
}
