package com.fawrysystem.forms;


import java.util.ArrayList;


public class VodafoneInternetForm {
    private static ArrayList<VodafoneInternetForm> vodafoneInternetForms= new ArrayList<>();
    private int phoneNumber;
    private double tax=8.5;
    private double cost;

    public static ArrayList<VodafoneInternetForm> getVodafoneInternetForms() {
        return vodafoneInternetForms;
    }

    private String userName="null";

    public VodafoneInternetForm(int phoneNumber, double tax, double cost) {
        this.phoneNumber = phoneNumber;
        this.tax = tax;
        this.cost = cost;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public double getTax() {
        return tax;
    }

    public double getCost() {
        return cost;
    }

    public String getUserName() {
        return userName;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
