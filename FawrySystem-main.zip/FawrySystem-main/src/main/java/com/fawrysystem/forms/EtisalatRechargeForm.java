package com.fawrysystem.forms;
import java.util.ArrayList;



public class EtisalatRechargeForm {
    private static ArrayList<EtisalatRechargeForm> etisalatRechargeForms= new ArrayList<>();
    private int number;
    private double tax = 8.0;
    private double NewCredit;
    private double cost;
    private String userName= "null";

    public EtisalatRechargeForm(int number, double tax, double newCredit, double cost) {
        this.number = number;
        this.tax = tax;
        NewCredit = newCredit;
        this.cost = cost;
    }

    public int getNumber() {
        return number;
    }

    public double getTax() {
        return tax;
    }

    public double getNewCredit() {
        return NewCredit;
    }

    public double getCost() {
        return cost;
    }

    public String getUserName() {
        return userName;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public void setNewCredit(double newCredit) {
        NewCredit = newCredit;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public static ArrayList<EtisalatRechargeForm> getEtisalatRechargeForms() {
        return etisalatRechargeForms;
    }
}
