package com.fawrysystem.forms;


import java.util.ArrayList;



public class VodafoneRechargeForm {
    private static ArrayList<VodafoneRechargeForm> vodafoneRechargeForms= new ArrayList<>();
    private int number;
    private double tax = 8.0;

    public static ArrayList<VodafoneRechargeForm> getVodafoneRechargeForms() {
        return vodafoneRechargeForms;
    }

    private double newCredit;
    private double cost;
    private String userName="null";

    public VodafoneRechargeForm(int number, double tax, double newCredit, double cost) {
        this.number = number;
        this.tax = tax;
        newCredit = newCredit;
        this.cost = cost;
    }

    public int getNumber() {
        return number;
    }

    public double getTax() {
        return tax;
    }

    public double getNewCredit() {
        return newCredit;
    }

    public double getCost() {
        return cost;
    }

    public String getUserName() {
        return userName;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public void setNewCredit(double newCredit) {
        this.newCredit = newCredit;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
