package com.fawrysystem.forms;

import com.fawrysystem.Service.implementation.payment.WalletService;

public class WalletForm {
    private String userName;
    private double price;

    public String getUserName() {
        return userName;
    }

    public double getPrice() {
        return price;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
