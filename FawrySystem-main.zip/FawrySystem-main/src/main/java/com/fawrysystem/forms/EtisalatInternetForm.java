package com.fawrysystem.forms;
import java.util.ArrayList;

public class EtisalatInternetForm {
    private static ArrayList<EtisalatInternetForm> etisalatInternetForms= new ArrayList<>();
    private double tax=8.0;
    private int phoneNumber;
    private double cost;
    private String userName="null";

    public EtisalatInternetForm(double tax, int phoneNumber, double cost) {
        this.tax = tax;
        this.phoneNumber = phoneNumber;
        this.cost = cost;
    }

    public double getTax() {
        return tax;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public double getCost() {
        return cost;
    }

    public String getUserName() {
        return userName;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public static ArrayList<EtisalatInternetForm> getEtisalatInternetForms() {
        return etisalatInternetForms;
    }
}
