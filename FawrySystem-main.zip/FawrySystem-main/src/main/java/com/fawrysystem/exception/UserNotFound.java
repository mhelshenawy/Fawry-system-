package com.fawrysystem.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_ACCEPTABLE)
public class UserNotFound extends RuntimeException {
    private String resourceName;
    private String filedName;
    private String flidValue;
    public UserNotFound(String resourceName, String filedName, String flidValue) {
        super(String.format("%s not found with %s : '%s'",resourceName,filedName,flidValue));
        this.resourceName = resourceName;
        this.filedName = filedName;
        this.flidValue = flidValue;
    }

    public String getResourceName() {
        return resourceName;
    }

    public String getFiledName() {
        return filedName;
    }

    public String getFlidValue() {
        return flidValue;
    }
}
