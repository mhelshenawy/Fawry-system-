package com.fawrysystem.controller;

import com.fawrysystem.Service.InternetPaymentService;
import com.fawrysystem.Service.NetworkCompanieService;
import com.fawrysystem.Service.Payment;
import com.fawrysystem.Service.RechargeService;
import com.fawrysystem.Service.implementation.networkservice.Etisalat.EtisalatFactoryService;
import com.fawrysystem.Service.implementation.networkservice.Vodafone.VodafoneFactoryService;
import com.fawrysystem.forms.EtisalatRechargeForm;
import com.fawrysystem.forms.VodafoneInternetForm;
import com.fawrysystem.forms.VodafoneRechargeForm;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/network")
public class NetworkController {
    NetworkCompanieService networkCompanieService;
    InternetPaymentService internetPaymentService;
    RechargeService rechargeService;
    @PostMapping("/vodafone/internet-payment/{number}")
    public ResponseEntity<Object> vodafoneInternetPaymentServiceResponseEntity(@PathVariable("number") int number ){
        networkCompanieService = new VodafoneFactoryService();
        internetPaymentService = networkCompanieService.createInternetPaymentService(number);
        return internetPaymentService.internetPaymentService(number);
    }
    @PostMapping("/etisalat/internet-payment/{number}")
    public ResponseEntity<Object> etisalatInternetPaymentServiceResponseEntity(@PathVariable("number") int number ){
        networkCompanieService = new EtisalatFactoryService();
        internetPaymentService = networkCompanieService.createInternetPaymentService(number);
        return internetPaymentService.internetPaymentService(number);
    }
    @PostMapping("/vodafone/recharge")
    public ResponseEntity<Object> vodafoneRechargeResponseEntity(@RequestBody VodafoneRechargeForm vodafoneRechargeForm){
        networkCompanieService = new VodafoneFactoryService();
        rechargeService= networkCompanieService.createRechargeService(vodafoneRechargeForm.getNumber(), vodafoneRechargeForm.getNewCredit());
        return rechargeService.rechargeService(vodafoneRechargeForm.getNumber(), vodafoneRechargeForm.getNewCredit());
    }
    @PostMapping("/etisalat/recharge")
    public ResponseEntity<Object> etisalatRechargeResponseEntity(@RequestBody EtisalatRechargeForm etisalatRechargeForm){
        networkCompanieService = new EtisalatFactoryService();
        rechargeService= networkCompanieService.createRechargeService(etisalatRechargeForm.getNumber(), etisalatRechargeForm.getNewCredit());
        return rechargeService.rechargeService(etisalatRechargeForm.getNumber(), etisalatRechargeForm.getNewCredit());
    }

}
