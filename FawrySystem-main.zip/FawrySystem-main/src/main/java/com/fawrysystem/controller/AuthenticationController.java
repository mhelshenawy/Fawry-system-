package com.fawrysystem.controller;

import com.fawrysystem.Service.SignService;
import com.fawrysystem.Service.implementation.signservice.AdminSingn;
import com.fawrysystem.Service.implementation.signservice.UserSingn;
import com.fawrysystem.models.AdminModel;
import com.fawrysystem.models.UserModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class AuthenticationController {
    private SignService signService ;
    @PostMapping("/user/sign-in")
    public ResponseEntity<UserModel> singinUser(@RequestBody UserModel userModel){
        signService = new UserSingn();
        UserModel model = (UserModel) signService.sinin(userModel);
        if (signService.sinin(userModel)!=null)
            return new ResponseEntity<UserModel>(model,HttpStatus.ACCEPTED);
        else return new ResponseEntity<UserModel>(HttpStatus.NOT_ACCEPTABLE);
    }
    @PostMapping("/user/sign-up")
    public ResponseEntity<UserModel> singupUser(@RequestBody UserModel userModel ){
        signService = new UserSingn();
        if (signService.sinup(userModel)!=null)
            return new ResponseEntity<UserModel>(userModel,HttpStatus.CREATED);
        else return new ResponseEntity<UserModel>(HttpStatus.NOT_ACCEPTABLE);
    }
    @PostMapping("/admin/sign-in")
    public ResponseEntity<AdminModel> singinAdmin(@RequestBody AdminModel adminModel){
        signService = new AdminSingn();
        AdminModel model = (AdminModel) signService.sinin(adminModel);
        if (signService.sinin(adminModel)!=null)
            return new ResponseEntity<AdminModel>(model,HttpStatus.ACCEPTED);
        else return new ResponseEntity<AdminModel>(HttpStatus.NOT_ACCEPTABLE);
    }
    @PostMapping("/admin/sign-up")
    public ResponseEntity<AdminModel> singupAdmin(@RequestBody AdminModel adminModel ){
        signService = new AdminSingn();
        if (signService.sinup(adminModel)!=null)
            return new ResponseEntity<AdminModel>(adminModel,HttpStatus.CREATED);
        else return new ResponseEntity<AdminModel>(HttpStatus.NOT_ACCEPTABLE);
    }
}
