package com.fawrysystem.controller;

import com.fawrysystem.Service.DonationFactory;
import com.fawrysystem.Service.DonationProvider;
import com.fawrysystem.Service.implementation.donation.CreateCancerHospital;
import com.fawrysystem.Service.implementation.donation.CreateSchoolsDonationService;
import com.fawrysystem.forms.CancerHospitalForm;
import com.fawrysystem.forms.SchoolsForm;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class DonationController {
    DonationFactory donationFactory;
    DonationProvider donationProvider;
    @PostMapping("/donation-school")
    public ResponseEntity<Object> schoolDonationResponseEntity(@RequestBody SchoolsForm schoolsForm){
        donationFactory =new CreateSchoolsDonationService();
        donationProvider =donationFactory.createDonation(schoolsForm.getName(),schoolsForm.getAmount());
        return donationProvider.DonationService(schoolsForm.getName(),schoolsForm.getAmount());
    }
    @PostMapping("/donation-cancerhospital")
    public ResponseEntity<Object> cancerHospitalDonationResponseEntity(@RequestBody CancerHospitalForm cancerHospital){
        donationFactory =new CreateCancerHospital();
        donationProvider =donationFactory.createDonation(cancerHospital.getName(),cancerHospital.getAmount());
        return donationProvider.DonationService(cancerHospital.getName(),cancerHospital.getAmount());
    }
}
