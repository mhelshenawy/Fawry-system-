package com.fawrysystem.controller;

import com.fawrysystem.Service.IListTransaction;
import com.fawrysystem.Service.implementation.AcceptRefundService;
import com.fawrysystem.Service.implementation.List.ListRefundTransactionService;
import com.fawrysystem.models.RefundTransactionModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/refund/admin")
public class ListRefundTransactionController {
    IListTransaction iListTransaction =new ListRefundTransactionService();
    AcceptRefundService addRefundService =new AcceptRefundService();
    @GetMapping("/list")
    public ResponseEntity<Object> listRefundTransaction(){
        return iListTransaction.ListTransaction();
    }
    @PostMapping("/accept")
    public ResponseEntity<Object> acceptRefunds(@RequestBody RefundTransactionModel refundTransactionModel){
        return addRefundService.acceptRefund(refundTransactionModel);
    }


}
