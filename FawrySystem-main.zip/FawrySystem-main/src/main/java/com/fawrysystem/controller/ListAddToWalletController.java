package com.fawrysystem.controller;

import com.fawrysystem.Service.IListTransaction;
import com.fawrysystem.Service.implementation.List.ListAddPaymetTransactionService;
import com.fawrysystem.Service.implementation.List.ListAddToWallet;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/wallet/admin")
public class ListAddToWalletController {
    IListTransaction iListTransaction =new ListAddToWallet();
    @GetMapping("/list")
    public ResponseEntity<Object> listPayTransaction(){
        return iListTransaction.ListTransaction();
    }
}
