package com.fawrysystem.controller;

import com.fawrysystem.Service.Refundtransaction;
import com.fawrysystem.Service.implementation.RefundTransactionService;
import com.fawrysystem.models.RefundTransactionModel;
import com.fawrysystem.repository.RefundTransactionRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/rufund")
public class AddRefundController {
    Refundtransaction refundtransaction = new RefundTransactionService();
    RefundTransactionRepository refundTransactionRepository =new RefundTransactionRepository();
    @GetMapping("/list")
    public ResponseEntity<Object> listRefundTransaction(){
        return refundtransaction.listUserTransaction();
    }
    @PostMapping("/add-refund")
    public ResponseEntity<Object> addRefund(@RequestBody RefundTransactionModel transactionModel){
        refundtransaction.addRefundTransaction(transactionModel);
        return new ResponseEntity<>(refundTransactionRepository.getRefundTransactionModels(), HttpStatus.OK);
    }
}
