package com.fawrysystem.controller;

import com.fawrysystem.Service.Payment;
import com.fawrysystem.Service.implementation.networkservice.Etisalat.EtisalatFactoryService;
import com.fawrysystem.Service.implementation.networkservice.Vodafone.VodafoneFactoryService;
import com.fawrysystem.Service.implementation.payment.WalletService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/payment")
public class PaymentController {
    VodafoneFactoryService vodafoneFactoryService= new VodafoneFactoryService();
    EtisalatFactoryService etisalatFactoryService;
    Payment payment;
    @GetMapping("/vodafone/internet-wallet")
    public ResponseEntity<Object> internetPaymentVodafonepayment(){
        payment =new WalletService();
        return payment.internetPaymentVodafone();
    }
    @GetMapping("/vodafone/recharge-wallet")
    public ResponseEntity<Object> rechargeVodafonePayment(){
        payment =new WalletService();
        return payment.rechargeVodafone();
    }
    @GetMapping("/etisalat/internet-wallet")
    public ResponseEntity<Object> internetPaymentEtisalatPayment(){
        payment= new WalletService();
        return payment.internetPaymentEtisalat();
    }
    @GetMapping("/etisalat/recharge-wallet")
    public ResponseEntity<Object> rechargeEtisalatPaymet(){
        payment= new WalletService();
        return payment.rechargeEtisalat();
    }
    @GetMapping("/donation-school")
    public ResponseEntity<Object> shoolsdonationPayment(){
        payment=new WalletService();
        return payment.schoolDonation();
    }
    @GetMapping("/donation-cancer-hospital")
    public ResponseEntity<Object> cancerHosptaldonationPayment(){
        payment=new WalletService();
        return payment.cancerHospitalDonation();
    }

}
