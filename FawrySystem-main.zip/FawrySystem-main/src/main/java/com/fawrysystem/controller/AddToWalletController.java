package com.fawrysystem.controller;
import com.fawrysystem.Service.AddToWallet;
import com.fawrysystem.Service.implementation.AddtoWalletService;
import com.fawrysystem.models.UserModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/wallet")
public class AddToWalletController {
    AddToWallet addToWallet=new AddtoWalletService();
    @PostMapping("/add")
    public ResponseEntity<Object> addTowallet(@RequestBody UserModel userModel){
        return addToWallet.add(userModel.getWallet());
    }
}
