package com.fawrysystem.controller;

import com.fawrysystem.Service.IListTransaction;
import com.fawrysystem.Service.implementation.List.ListAddPaymetTransactionService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/pay-transaction")
public class ListPayTransactionController {
    IListTransaction iListTransaction =new ListAddPaymetTransactionService();
    @GetMapping("/list")
    public ResponseEntity<Object> listPayTransaction(){
        return iListTransaction.ListTransaction();
    }
}
