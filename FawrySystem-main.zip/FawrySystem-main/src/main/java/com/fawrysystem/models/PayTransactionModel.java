package com.fawrysystem.models;


public class PayTransactionModel {
    private String transactionName;
    private String userName;
    private double price;

    public String getTransactionName() {
        return transactionName;
    }

    public String getUserName() {
        return userName;
    }

    public double getPrice() {
        return price;
    }

    public void setTransactionName(String transactionName) {
        this.transactionName = transactionName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
