package com.fawrysystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FawrySystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
